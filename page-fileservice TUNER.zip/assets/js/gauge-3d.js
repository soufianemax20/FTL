/**
 * TUNER FILES LAB - Hyper-Real 3D Gauge
 * EXACT IMPLEMENTATION FROM USER REQUEST
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { FontLoader } from 'three/addons/loaders/FontLoader.js';
import { TextGeometry } from 'three/addons/geometries/TextGeometry.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

// --- INIT WRAPPER ---
function init() {
    console.log("Initializing 3D Gauge...");
    const container = document.getElementById('gauge-container');
    if (!container) {
        console.warn("Gauge container not found, retrying...");
        setTimeout(init, 500);
        return;
    }

    // Clear loading text if present
    container.innerHTML = '';

    // --- COLORS (Calibrated for Realism) ---
    const C_YELLOW = new THREE.Color(0xdfff00).convertSRGBToLinear();
    const C_RED = new THREE.Color(0xd60000).convertSRGBToLinear();
    const C_CARBON = new THREE.Color(0x111111).convertSRGBToLinear();
    const C_METAL = new THREE.Color(0x888888).convertSRGBToLinear();
    const C_CHROME = new THREE.Color(0xffffff).convertSRGBToLinear();

    // --- SCENE SETUP ---
    const scene = new THREE.Scene();
    scene.background = null;

    const camera = new THREE.PerspectiveCamera(40, container.offsetWidth / container.offsetHeight, 0.1, 100);
    camera.position.set(0, -1, 18);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.offsetWidth, container.offsetHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    renderer.toneMapping = THREE.ReinhardToneMapping;
    renderer.toneMappingExposure = 1.0;

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;

    container.appendChild(renderer.domElement);

    // --- CONTROLS ---
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.enablePan = false;
    controls.minPolarAngle = Math.PI / 4;
    controls.maxPolarAngle = Math.PI / 1.6;

    // --- TEXTURES (Procedural) ---
    function getCarbonNormalMap() {
        const canvas = document.createElement('canvas');
        canvas.width = 512; canvas.height = 512;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#8080ff';
        ctx.fillRect(0, 0, 512, 512);

        for (let i = 0; i < 512; i += 8) {
            for (let j = 0; j < 512; j += 8) {
                const bright = (i + j) % 16 === 0;
                ctx.fillStyle = bright ? '#a0a0ff' : '#6060ff';
                ctx.fillRect(i, j, 4, 4);
                ctx.fillStyle = bright ? '#6060ff' : '#a0a0ff';
                ctx.fillRect(i + 4, j + 4, 4, 4);
            }
        }
        const tex = new THREE.CanvasTexture(canvas);
        tex.wrapS = THREE.RepeatWrapping;
        tex.wrapT = THREE.RepeatWrapping;
        tex.repeat.set(2, 2);
        return tex;
    }

    // --- MATERIALS ---

    const matCarbon = new THREE.MeshPhysicalMaterial({
        color: C_CARBON,
        roughness: 0.3,
        metalness: 0.1,
        clearcoat: 1.0,
        clearcoatRoughness: 0.1,
        normalMap: getCarbonNormalMap(),
        normalScale: new THREE.Vector2(0.3, 0.3)
    });

    const matBrushed = new THREE.MeshPhysicalMaterial({
        color: C_METAL,
        roughness: 0.25,
        metalness: 1.0,
        clearcoat: 0.1,
        anisotropy: 16
    });

    const matPaintYellow = new THREE.MeshPhysicalMaterial({
        color: C_YELLOW,
        roughness: 0.2,
        metalness: 0.1,
        clearcoat: 1.0,
        clearcoatRoughness: 0.05,
        emissive: C_YELLOW,
        emissiveIntensity: 0.2
    });

    const matPaintRed = new THREE.MeshPhysicalMaterial({
        color: C_RED,
        roughness: 0.2,
        metalness: 0.1,
        clearcoat: 1.0,
        emissive: C_RED,
        emissiveIntensity: 0.4
    });

    const matGlass = new THREE.MeshPhysicalMaterial({
        color: 0xffffff,
        metalness: 0.0,
        roughness: 0.0,
        transmission: 0.99,
        thickness: 1.5,
        ior: 1.5,
        transparent: true,
        opacity: 1.0
    });

    const matChrome = new THREE.MeshPhysicalMaterial({
        color: C_CHROME,
        metalness: 1.0,
        roughness: 0.05
    });

    // --- GEOMETRY ---
    const dashboard = new THREE.Group();

    // 1. Case (Carbon)
    const caseGeo = new RoundedBoxGeometry(8, 9.5, 1.2, 8, 1.5);
    const caseMesh = new THREE.Mesh(caseGeo, matCarbon);
    caseMesh.position.y = -0.75;
    caseMesh.position.z = -0.5;
    caseMesh.receiveShadow = true;
    caseMesh.castShadow = true;
    dashboard.add(caseMesh);

    // 2. Bezel Ring (Chrome)
    const ringGeo = new THREE.TorusGeometry(3.6, 0.1, 16, 64);
    const ringMesh = new THREE.Mesh(ringGeo, matChrome);
    ringMesh.position.z = 0.55;
    dashboard.add(ringMesh);

    // 3. Dial Plate (Brushed Metal)
    const dialGeo = new THREE.CylinderGeometry(3.5, 3.5, 0.2, 64);
    dialGeo.rotateX(Math.PI / 2);
    const dialMesh = new THREE.Mesh(dialGeo, matBrushed);
    dialMesh.receiveShadow = true;
    dashboard.add(dialMesh);

    // 4. Logo Elements
    const extrudeSettings = { depth: 0.2, bevelEnabled: true, bevelSegments: 2, steps: 1, bevelSize: 0.05, bevelThickness: 0.05 };

    // Stem
    const stemShape = new THREE.Shape();
    stemShape.moveTo(-1.0, -2.5);
    stemShape.lineTo(1.0, -2.5);
    stemShape.lineTo(1.5, 0);
    stemShape.lineTo(-1.5, 0);
    stemShape.lineTo(-1.0, -2.5);
    const stemMesh = new THREE.Mesh(new THREE.ExtrudeGeometry(stemShape, extrudeSettings), matPaintYellow);
    stemMesh.position.z = 0.1;
    stemMesh.castShadow = true;
    dashboard.add(stemMesh);

    // Arcs
    const yellowArcShape = new THREE.Shape();
    yellowArcShape.absarc(0, 0, 3.2, Math.PI, Math.PI * 0.25, true);
    const yHole = new THREE.Path(); yHole.absarc(0, 0, 2.8, Math.PI, Math.PI * 0.25, true);
    yellowArcShape.holes.push(yHole);
    const yellowArc = new THREE.Mesh(new THREE.ExtrudeGeometry(yellowArcShape, extrudeSettings), matPaintYellow);
    yellowArc.position.z = 0.1;
    yellowArc.castShadow = true;
    dashboard.add(yellowArc);

    const redArcShape = new THREE.Shape();
    redArcShape.absarc(0, 0, 3.2, Math.PI * 0.25, 0, true);
    const rHole = new THREE.Path(); rHole.absarc(0, 0, 2.8, Math.PI * 0.25, 0, true);
    redArcShape.holes.push(rHole);
    const redArc = new THREE.Mesh(new THREE.ExtrudeGeometry(redArcShape, extrudeSettings), matPaintRed);
    redArc.position.z = 0.1;
    redArc.castShadow = true;
    dashboard.add(redArc);

    // 5. Ticks
    for (let i = 0; i <= 40; i++) {
        const angle = Math.PI - (i / 40) * Math.PI;
        const isMajor = i % 5 === 0;
        const w = isMajor ? 0.08 : 0.04;
        const h = isMajor ? 0.4 : 0.2;
        const dist = isMajor ? 3.0 : 3.1;

        const tickGeo = new THREE.BoxGeometry(h, w, 0.05);
        const tickMat = (i < 30) ? matChrome : matPaintRed;
        const tick = new THREE.Mesh(tickGeo, tickMat);

        tick.position.x = Math.cos(angle) * dist;
        tick.position.y = Math.sin(angle) * dist;
        tick.position.z = 0.25;
        tick.rotation.z = angle;
        dashboard.add(tick);
    }

    // 6. Needle Assembly
    const needleGroup = new THREE.Group();
    const pointerGeo = new THREE.BoxGeometry(2.0, 0.15, 0.05);
    pointerGeo.translate(1.0, 0, 0);
    const pointerMesh = new THREE.Mesh(pointerGeo, matPaintRed);
    needleGroup.add(pointerMesh);

    const capGeo = new THREE.CylinderGeometry(0.5, 0.6, 0.3, 32);
    capGeo.rotateX(Math.PI / 2);
    const capMesh = new THREE.Mesh(capGeo, matChrome);
    needleGroup.add(capMesh);

    needleGroup.position.z = 0.4;
    needleGroup.rotation.z = Math.PI;
    dashboard.add(needleGroup);

    // 7. Glass Lens
    const lensGeo = new THREE.SphereGeometry(3.6, 64, 16, 0, Math.PI * 2, 0, Math.PI * 0.25);
    lensGeo.scale(1, 1, 0.2);
    const lensMesh = new THREE.Mesh(lensGeo, matGlass);
    lensMesh.position.z = 0.6;
    dashboard.add(lensMesh);

    // 8. Text
    // Note: We keep the text logic, but ensure it handles errors gracefully if font fails load
    const loader = new FontLoader();
    loader.load('https://unpkg.com/three@0.160.0/examples/fonts/helvetiker_bold.typeface.json', function (font) {

        const textGeo = new TextGeometry('TUNER FILES LAB', {
            font: font, size: 0.5, height: 0.05,
            curveSegments: 12, bevelEnabled: true, bevelThickness: 0.03, bevelSize: 0.01, bevelSegments: 3
        });
        textGeo.center();

        const textMesh = new THREE.Mesh(textGeo, matChrome);
        textMesh.position.y = -4.2;
        textMesh.position.z = 0.15;
        textMesh.castShadow = true;
        dashboard.add(textMesh);
    }, undefined, function (err) {
        console.error("Font loading failed:", err);
    });

    scene.add(dashboard);

    // --- LIGHTING ---
    const spotLight = new THREE.SpotLight(0xffffff, 500);
    spotLight.position.set(-5, 10, 10);
    spotLight.angle = 0.5;
    spotLight.penumbra = 0.5;
    spotLight.castShadow = true;
    spotLight.shadow.bias = -0.0001;
    spotLight.shadow.mapSize.width = 2048;
    spotLight.shadow.mapSize.height = 2048;
    scene.add(spotLight);

    const fillLight = new THREE.PointLight(0xffffff, 200);
    fillLight.position.set(5, -5, 5);
    scene.add(fillLight);

    // --- ANIMATION FOR AUTO-DEMO ---
    let needleAngle = Math.PI;
    let needleVelocity = 0;
    let targetRPM = 0;
    const clock = new THREE.Clock();

    function animate() {
        requestAnimationFrame(animate);

        const dt = Math.min(clock.getDelta(), 0.1);
        const time = clock.getElapsedTime();

        // RPM Logic
        if (Math.floor(time) % 3 === 0) {
            const r = Math.random();
            if (r > 0.6) targetRPM = 0.85;       // Redline
            else if (r > 0.3) targetRPM = 0.3;   // Cruise
            else targetRPM = 0.05;              // Idle
        }
        const jitter = (Math.sin(time * 50) * 0.01);

        // Physics
        const targetAngle = Math.PI - ((targetRPM + jitter) * Math.PI);
        const tension = 15.0;
        const damping = 6.0;
        const force = tension * (targetAngle - needleAngle);
        const acceleration = force - (needleVelocity * damping);

        needleVelocity += acceleration * dt;
        needleAngle += needleVelocity * dt;
        needleGroup.rotation.z = needleAngle;

        // Presentation Float
        dashboard.rotation.y = Math.sin(time * 0.5) * 0.08;
        dashboard.rotation.x = Math.cos(time * 0.4) * 0.05;

        controls.update();
        renderer.render(scene, camera);
    }

    window.addEventListener('resize', () => {
        camera.aspect = container.offsetWidth / container.offsetHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(container.offsetWidth, container.offsetHeight);
    });

    animate();
}

// Start
init();
