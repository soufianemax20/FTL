/**
 * Hero 3D Engine - "The Digital Core"
 * Needs: Three.js
 * 
 * Creates an immersive, rotating procedural engine core / ECU brain
 * that floats in a void space and reacts to mouse movement.
 */

document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('hero-3d-container');
    if (!container) return; // Exit if no container

    // Scene Setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x050505, 0.03); // Deep fog for depth

    // Camera
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.z = 25;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
        alpha: true,
        antialias: true,
        powerPreference: "high-performance"
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // Limit pixel ratio for performance
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(renderer.domElement);

    // Resize Handler
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });

    // --- GEOMETRY: The "Tech Core" ---
    const coreGroup = new THREE.Group();
    scene.add(coreGroup);

    // 1. Central "ECU" Frame (Wireframe Cage)
    const frameGeo = new THREE.BoxGeometry(10, 14, 6);
    const frameMat = new THREE.MeshBasicMaterial({
        color: 0xD7F207, // Neon Lime
        wireframe: true,
        transparent: true,
        opacity: 0.2
    });
    const frameMesh = new THREE.Mesh(frameGeo, frameMat);
    coreGroup.add(frameMesh);

    // 2. Inner Digital Block (Solid with sheen)
    const innerGeo = new THREE.BoxGeometry(8, 12, 4);
    const innerMat = new THREE.MeshPhysicalMaterial({
        color: 0x0a0a0a,
        emissive: 0x000000,
        metalness: 0.9,
        roughness: 0.2,
        clearcoat: 1.0,
        clearcoatRoughness: 0.1,
        transparent: true,
        opacity: 0.95
    });
    const innerMesh = new THREE.Mesh(innerGeo, innerMat);
    coreGroup.add(innerMesh);

    // 3. Floating Data Lines (Scanning effect)
    const linesGroup = new THREE.Group();
    coreGroup.add(linesGroup);

    // Create random floating lines inside/around
    for (let i = 0; i < 10; i++) {
        const lineGeo = new THREE.BoxGeometry(9, 0.1, 5);
        const lineMat = new THREE.MeshBasicMaterial({
            color: 0xD7F207,
            transparent: true,
            opacity: 0.3
        });
        const line = new THREE.Mesh(lineGeo, lineMat);
        line.position.y = (Math.random() - 0.5) * 12;
        linesGroup.add(line);
    }

    // 4. Orbiting Rings (Cyberpunk vibe)
    const ringGeo = new THREE.TorusGeometry(14, 0.05, 16, 100);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x555555, transparent: true, opacity: 0.4 });

    const ring1 = new THREE.Mesh(ringGeo, ringMat);
    const ring2 = new THREE.Mesh(ringGeo, ringMat);

    ring1.rotation.x = Math.PI / 2; // Horizontal
    ring1.rotation.y = 0.2;

    ring2.rotation.x = Math.PI / 1.8;
    ring2.rotation.y = Math.PI / 4;

    coreGroup.add(ring1);
    coreGroup.add(ring2);

    // 5. Particles Dust (Atmosphere)
    const particleCount = 400;
    const particlesGeo = new THREE.BufferGeometry();
    const posArray = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i++) {
        posArray[i] = (Math.random() - 0.5) * 60; // Wide spread
    }
    particlesGeo.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    const particlesMat = new THREE.PointsMaterial({
        size: 0.15,
        color: 0xD7F207,
        transparent: true,
        opacity: 0.6,
        blending: THREE.AdditiveBlending
    });
    const particleMesh = new THREE.Points(particlesGeo, particlesMat);
    scene.add(particleMesh);

    // --- LIGHTING ---
    const ambientLight = new THREE.AmbientLight(0x222222, 1);
    scene.add(ambientLight);

    // Main Neon Light (Dynamic)
    const pointLight = new THREE.PointLight(0xD7F207, 3, 60);
    pointLight.position.set(10, 10, 10);
    scene.add(pointLight);

    // Fill Light (Cool Blue for contrast)
    const fillLight = new THREE.PointLight(0x0088ff, 1, 50);
    fillLight.position.set(-10, -5, 10);
    scene.add(fillLight);

    // Back Light (Rim)
    const backLight = new THREE.PointLight(0xffffff, 2, 40);
    backLight.position.set(0, 5, -20);
    scene.add(backLight);

    // --- INTERACTION ---
    let mouseX = 0;
    let mouseY = 0;
    let targetRotationX = 0;
    let targetRotationY = 0;

    document.addEventListener('mousemove', (event) => {
        // Normalize mouse speed (0-1 range around center)
        mouseX = (event.clientX / window.innerWidth) - 0.5;
        mouseY = (event.clientY / window.innerHeight) - 0.5;
    });

    // --- ANIMATION LOOP ---
    const clock = new THREE.Clock();

    function animate() {
        requestAnimationFrame(animate);
        const elapsedTime = clock.getElapsedTime();

        // 1. Core Rotation (Smooth damping)
        const targetRotY = mouseX * 0.5; // Look horizontal
        const targetRotX = mouseY * 0.5; // Look vertical

        coreGroup.rotation.y += 0.003; // Constant faint spin

        // Lerp towards mouse position
        coreGroup.rotation.y += (targetRotY - coreGroup.rotation.y) * 0.05;
        coreGroup.rotation.x += (targetRotX - coreGroup.rotation.x) * 0.05;

        // Bobbing effect
        coreGroup.position.y = Math.sin(elapsedTime * 0.8) * 0.5;

        // 2. Rings Animation
        ring1.rotation.z += 0.002;
        ring2.rotation.z -= 0.002;

        // 3. Pulse Light
        pointLight.intensity = 3 + Math.sin(elapsedTime * 3) * 0.5;

        // 4. Scanning Lines
        linesGroup.children.forEach((line, i) => {
            line.scale.x = 1 + Math.sin(elapsedTime * 2 + i) * 0.2;
        });

        // 5. Particles Parallax
        particleMesh.rotation.y = -mouseX * 0.2;
        particleMesh.rotation.x = -mouseY * 0.2;

        renderer.render(scene, camera);
    }

    animate();
});

// Scroll Reveal Observer (Re-integrated)
document.addEventListener('DOMContentLoaded', () => {
    const revealElements = document.querySelectorAll('.hero-content, .hero-stats, .btn-lambo');

    // Add initial state
    revealElements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = `opacity 0.8s ease ${index * 0.2}s, transform 0.8s ease ${index * 0.2}s`;
    });

    // Simple reveal on load
    setTimeout(() => {
        revealElements.forEach(el => {
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
        });
    }, 500);
});
