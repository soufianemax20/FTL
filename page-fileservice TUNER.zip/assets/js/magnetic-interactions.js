/**
 * Magnetic Buttons Interaction
 * 
 * Applies a "magnetic" pull effect to buttons and interactive elements,
 * giving them a premium, physical feel as if they are attracted to the cursor.
 */

class MagneticButton {
    constructor(el) {
        this.el = el;
        this.boundingRect = this.el.getBoundingClientRect();
        this.init();
    }

    init() {
        this.el.addEventListener('mousemove', (e) => this.onMouseMove(e));
        this.el.addEventListener('mouseleave', (e) => this.onMouseLeave(e));
        window.addEventListener('resize', () => this.onResize());
    }

    onResize() {
        this.boundingRect = this.el.getBoundingClientRect();
    }

    onMouseMove(e) {
        // Recalculate in case of scroll
        this.boundingRect = this.el.getBoundingClientRect();

        const x = (e.clientX - this.boundingRect.left) - this.boundingRect.width / 2;
        const y = (e.clientY - this.boundingRect.top) - this.boundingRect.height / 2;

        // Apply transform with smooth easing
        this.el.style.transform = `translate(${x * 0.3}px, ${y * 0.3}px)`;

        // If it has a child span/text, move it for parallax depth
        const text = this.el.querySelector('span');
        if (text) {
            text.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px)`;
        }
    }

    onMouseLeave(e) {
        // Snap back to origin
        this.el.style.transform = `translate(0px, 0px)`;
        const text = this.el.querySelector('span');
        if (text) {
            text.style.transform = `translate(0px, 0px)`;
        }
    }
}

// Init when DOM loads
document.addEventListener('DOMContentLoaded', () => {
    // Select all primary buttons and magnetic-wrap elements, including nav links
    const buttons = document.querySelectorAll('.btn-lambo, .btn-primary, .btn-magnetic, .magnetic-wrap, .nav-link, .btn-neon, .btn-outline-neon');

    buttons.forEach(btn => {
        // Add transition style for smoothness
        btn.style.transition = 'transform 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
        new MagneticButton(btn);
    });
});
