<style>
    .ctr-custom-box{text-align: center;}
    .ctr-custom-box:hover {box-shadow: 0px 4px 20px -5px rgba(80, 70, 228, 0.71);border-radius: 16px;}  
    .text-ctr-orange {color: #f9876d;}
    .text-ctr-blue {color: #0079d9;}
    .rubik {font-family: "Rubik", Sans-serif;}
    h3 {font-size: 1.75rem!Important;}
    .ctr-flex-col {flex-direction: column;}
    .ctr-flex-row {flex-direction: row;}
    .md\:ctr-flex-row {
        flex-direction: row;
    }
    .md\:ctr-flex-col {
        flex-direction: column;
    }
</style>