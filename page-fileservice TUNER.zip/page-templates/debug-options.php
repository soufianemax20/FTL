<?php
/**
 * Template Name: Debug Options
 * Description: Find the option name for the API key.
 */
get_header(); 
?>
<div class="container mx-auto p-12 text-white bg-black">
    <pre>
<?php
global $wpdb;
$options = $wpdb->get_results("SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE '%ctr%' OR option_name LIKE '%chiptuning%'");
print_r($options);
?>
    </pre>
</div>
<?php get_footer(); ?>